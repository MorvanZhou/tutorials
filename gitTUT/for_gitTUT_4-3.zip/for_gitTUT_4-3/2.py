a = 2
b = 1
c = b
